﻿namespace MyNote
{
    partial class FormDiary
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージド リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode71 = new System.Windows.Forms.TreeNode("Work");
            System.Windows.Forms.TreeNode treeNode72 = new System.Windows.Forms.TreeNode("Life");
            System.Windows.Forms.TreeNode treeNode73 = new System.Windows.Forms.TreeNode("Learn");
            System.Windows.Forms.TreeNode treeNode74 = new System.Windows.Forms.TreeNode("Play");
            System.Windows.Forms.TreeNode treeNode75 = new System.Windows.Forms.TreeNode("Total", new System.Windows.Forms.TreeNode[] {
            treeNode71,
            treeNode72,
            treeNode73,
            treeNode74});
            System.Windows.Forms.TreeNode treeNode76 = new System.Windows.Forms.TreeNode("Work");
            System.Windows.Forms.TreeNode treeNode77 = new System.Windows.Forms.TreeNode("Life");
            System.Windows.Forms.TreeNode treeNode78 = new System.Windows.Forms.TreeNode("Learn");
            System.Windows.Forms.TreeNode treeNode79 = new System.Windows.Forms.TreeNode("Play");
            System.Windows.Forms.TreeNode treeNode80 = new System.Windows.Forms.TreeNode("Total", new System.Windows.Forms.TreeNode[] {
            treeNode76,
            treeNode77,
            treeNode78,
            treeNode79});
            System.Windows.Forms.TreeNode treeNode81 = new System.Windows.Forms.TreeNode("Work");
            System.Windows.Forms.TreeNode treeNode82 = new System.Windows.Forms.TreeNode("Life");
            System.Windows.Forms.TreeNode treeNode83 = new System.Windows.Forms.TreeNode("Learn");
            System.Windows.Forms.TreeNode treeNode84 = new System.Windows.Forms.TreeNode("Play");
            System.Windows.Forms.TreeNode treeNode85 = new System.Windows.Forms.TreeNode("Total", new System.Windows.Forms.TreeNode[] {
            treeNode81,
            treeNode82,
            treeNode83,
            treeNode84});
            System.Windows.Forms.TreeNode treeNode86 = new System.Windows.Forms.TreeNode("Work");
            System.Windows.Forms.TreeNode treeNode87 = new System.Windows.Forms.TreeNode("Life");
            System.Windows.Forms.TreeNode treeNode88 = new System.Windows.Forms.TreeNode("Learn");
            System.Windows.Forms.TreeNode treeNode89 = new System.Windows.Forms.TreeNode("Play");
            System.Windows.Forms.TreeNode treeNode90 = new System.Windows.Forms.TreeNode("Total", new System.Windows.Forms.TreeNode[] {
            treeNode86,
            treeNode87,
            treeNode88,
            treeNode89});
            System.Windows.Forms.TreeNode treeNode91 = new System.Windows.Forms.TreeNode("Work");
            System.Windows.Forms.TreeNode treeNode92 = new System.Windows.Forms.TreeNode("Life");
            System.Windows.Forms.TreeNode treeNode93 = new System.Windows.Forms.TreeNode("Learn");
            System.Windows.Forms.TreeNode treeNode94 = new System.Windows.Forms.TreeNode("Play");
            System.Windows.Forms.TreeNode treeNode95 = new System.Windows.Forms.TreeNode("Total", new System.Windows.Forms.TreeNode[] {
            treeNode91,
            treeNode92,
            treeNode93,
            treeNode94});
            System.Windows.Forms.TreeNode treeNode96 = new System.Windows.Forms.TreeNode("Work");
            System.Windows.Forms.TreeNode treeNode97 = new System.Windows.Forms.TreeNode("Life");
            System.Windows.Forms.TreeNode treeNode98 = new System.Windows.Forms.TreeNode("Learn");
            System.Windows.Forms.TreeNode treeNode99 = new System.Windows.Forms.TreeNode("Play");
            System.Windows.Forms.TreeNode treeNode100 = new System.Windows.Forms.TreeNode("Total", new System.Windows.Forms.TreeNode[] {
            treeNode96,
            treeNode97,
            treeNode98,
            treeNode99});
            System.Windows.Forms.TreeNode treeNode101 = new System.Windows.Forms.TreeNode("Work");
            System.Windows.Forms.TreeNode treeNode102 = new System.Windows.Forms.TreeNode("Life");
            System.Windows.Forms.TreeNode treeNode103 = new System.Windows.Forms.TreeNode("Learn");
            System.Windows.Forms.TreeNode treeNode104 = new System.Windows.Forms.TreeNode("Play");
            System.Windows.Forms.TreeNode treeNode105 = new System.Windows.Forms.TreeNode("Total", new System.Windows.Forms.TreeNode[] {
            treeNode101,
            treeNode102,
            treeNode103,
            treeNode104});
            this.treeViewCategory = new System.Windows.Forms.TreeView();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.buttonAddSelectRows = new System.Windows.Forms.Button();
            this.dataGridViewEvent = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.DataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.buttonCItemClear = new System.Windows.Forms.Button();
            this.buttonTagAdd = new System.Windows.Forms.Button();
            this.textBoxTagAdd = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.textBoxCItemId = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.textBoxCItemName3 = new System.Windows.Forms.TextBox();
            this.textBoxCItemName2 = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.buttonCItemDelete = new System.Windows.Forms.Button();
            this.buttonCItemUpdate = new System.Windows.Forms.Button();
            this.buttonCItemAdd = new System.Windows.Forms.Button();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.label24 = new System.Windows.Forms.Label();
            this.textBoxCItemIndex = new System.Windows.Forms.TextBox();
            this.textBoxCItemTitle = new System.Windows.Forms.TextBox();
            this.textBoxCItemMemo = new System.Windows.Forms.TextBox();
            this.treeViewCollectionDetail = new System.Windows.Forms.TreeView();
            this.label25 = new System.Windows.Forms.Label();
            this.textBoxCReleaseDate = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.textBoxCInputDate = new System.Windows.Forms.TextBox();
            this.buttonCollectionDelete = new System.Windows.Forms.Button();
            this.buttonCollectionClear = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxCName3 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxCName2 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxCId = new System.Windows.Forms.TextBox();
            this.buttonCollectionUpdate = new System.Windows.Forms.Button();
            this.buttonCollectionAdd = new System.Windows.Forms.Button();
            this.textBoxCStatus = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxCCategory = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.textBoxCLevel = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.textBoxCMemo = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.textBoxCName = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.checkedListBoxCTags = new System.Windows.Forms.CheckedListBox();
            this.treeViewCollection = new System.Windows.Forms.TreeView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label39 = new System.Windows.Forms.Label();
            this.textBoxFReleaseDate = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.textBoxFInputDate = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxFItemId = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.textBoxFItemName3 = new System.Windows.Forms.TextBox();
            this.textBoxFItemName2 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.buttonFItemDelete = new System.Windows.Forms.Button();
            this.buttonFItemUpdate = new System.Windows.Forms.Button();
            this.buttonFItemAdd = new System.Windows.Forms.Button();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.label38 = new System.Windows.Forms.Label();
            this.textBoxFItemIndex = new System.Windows.Forms.TextBox();
            this.textBoxFItemName = new System.Windows.Forms.TextBox();
            this.textBoxFItemMemo = new System.Windows.Forms.TextBox();
            this.treeViewFantasyDetail = new System.Windows.Forms.TreeView();
            this.buttonFDelete = new System.Windows.Forms.Button();
            this.buttonFClear = new System.Windows.Forms.Button();
            this.label41 = new System.Windows.Forms.Label();
            this.textBoxFName3 = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.textBoxFName2 = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.textBoxFId = new System.Windows.Forms.TextBox();
            this.buttonFUpdate = new System.Windows.Forms.Button();
            this.buttonFAdd = new System.Windows.Forms.Button();
            this.textBoxFStatus = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.textBoxFCategory = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.textBoxFLevel = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.textBoxFMemo = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.textBoxFName = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.checkedListBoxFTags = new System.Windows.Forms.CheckedListBox();
            this.treeViewFantasy = new System.Windows.Forms.TreeView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.buttonPersonDelete = new System.Windows.Forms.Button();
            this.buttonPersonClear = new System.Windows.Forms.Button();
            this.dataGridViewPersonGroup = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label19 = new System.Windows.Forms.Label();
            this.textBoxPersonName3 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.textBoxPersonName2 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.textBoxPersonId = new System.Windows.Forms.TextBox();
            this.buttonPersonUpdate = new System.Windows.Forms.Button();
            this.buttonPersonAdd = new System.Windows.Forms.Button();
            this.textBoxPersonStatus = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.textBoxPersonGroup = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxPersonAddress = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxPersonMemo = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxPersonName = new System.Windows.Forms.TextBox();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.treeViewPerson = new System.Windows.Forms.TreeView();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.dataGridViewCategoryList = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label15 = new System.Windows.Forms.Label();
            this.textBoxCategoryParent = new System.Windows.Forms.TextBox();
            this.buttonAddCategory = new System.Windows.Forms.Button();
            this.dataGridViewCategory = new System.Windows.Forms.DataGridView();
            this.CategoryName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ParentCategory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.buttonUpdateCategory = new System.Windows.Forms.Button();
            this.dateTimePickerCategory = new System.Windows.Forms.DateTimePicker();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textBoxCategoryName = new System.Windows.Forms.TextBox();
            this.buttonEventSave = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.buttonEventView = new System.Windows.Forms.Button();
            this.buttonUpdate = new System.Windows.Forms.Button();
            this.buttonBackup = new System.Windows.Forms.Button();
            this.buttonEventSearch = new System.Windows.Forms.Button();
            this.textBoxEventSearch = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEvent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPersonGroup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCategoryList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCategory)).BeginInit();
            this.SuspendLayout();
            // 
            // treeViewCategory
            // 
            this.treeViewCategory.Location = new System.Drawing.Point(985, 17);
            this.treeViewCategory.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.treeViewCategory.Name = "treeViewCategory";
            treeNode71.Name = "ノード1";
            treeNode71.Text = "Work";
            treeNode72.Name = "ノード2";
            treeNode72.Text = "Life";
            treeNode73.Name = "ノード3";
            treeNode73.Text = "Learn";
            treeNode74.Name = "ノード4";
            treeNode74.Text = "Play";
            treeNode75.Name = "ノード0";
            treeNode75.Text = "Total";
            this.treeViewCategory.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode75});
            this.treeViewCategory.Size = new System.Drawing.Size(877, 991);
            this.treeViewCategory.TabIndex = 18;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tabControl1.Location = new System.Drawing.Point(18, 59);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(2600, 1550);
            this.tabControl1.TabIndex = 6;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.textBoxEventSearch);
            this.tabPage1.Controls.Add(this.buttonEventSearch);
            this.tabPage1.Controls.Add(this.buttonAddSelectRows);
            this.tabPage1.Controls.Add(this.dataGridViewEvent);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.treeView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 31);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Size = new System.Drawing.Size(2592, 1515);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Event";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // buttonAddSelectRows
            // 
            this.buttonAddSelectRows.Font = new System.Drawing.Font("Webdings", 8.25F);
            this.buttonAddSelectRows.Location = new System.Drawing.Point(1053, 448);
            this.buttonAddSelectRows.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttonAddSelectRows.Name = "buttonAddSelectRows";
            this.buttonAddSelectRows.Size = new System.Drawing.Size(45, 36);
            this.buttonAddSelectRows.TabIndex = 9;
            this.buttonAddSelectRows.Text = "8";
            this.buttonAddSelectRows.UseVisualStyleBackColor = true;
            this.buttonAddSelectRows.Click += new System.EventHandler(this.buttonAddSelectRows_Click);
            // 
            // dataGridViewEvent
            // 
            this.dataGridViewEvent.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewEvent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewEvent.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1});
            this.dataGridViewEvent.Location = new System.Drawing.Point(1104, 7);
            this.dataGridViewEvent.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridViewEvent.Name = "dataGridViewEvent";
            this.dataGridViewEvent.RowTemplate.Height = 24;
            this.dataGridViewEvent.Size = new System.Drawing.Size(1482, 923);
            this.dataGridViewEvent.TabIndex = 2;
            this.dataGridViewEvent.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewEvent_CellEndEdit);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "EventName";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DataGridViewTextBoxColumn9});
            this.dataGridView1.Location = new System.Drawing.Point(479, 56);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(568, 874);
            this.dataGridView1.TabIndex = 1;
            // 
            // DataGridViewTextBoxColumn9
            // 
            this.DataGridViewTextBoxColumn9.HeaderText = "RefName";
            this.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9";
            // 
            // treeView1
            // 
            this.treeView1.Location = new System.Drawing.Point(8, 7);
            this.treeView1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.treeView1.Name = "treeView1";
            treeNode76.Name = "ノード1";
            treeNode76.Text = "Work";
            treeNode77.Name = "ノード2";
            treeNode77.Text = "Life";
            treeNode78.Name = "ノード3";
            treeNode78.Text = "Learn";
            treeNode79.Name = "ノード4";
            treeNode79.Text = "Play";
            treeNode80.Name = "ノード0";
            treeNode80.Text = "Total";
            this.treeView1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode80});
            this.treeView1.Size = new System.Drawing.Size(465, 923);
            this.treeView1.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.buttonCItemClear);
            this.tabPage2.Controls.Add(this.buttonTagAdd);
            this.tabPage2.Controls.Add(this.textBoxTagAdd);
            this.tabPage2.Controls.Add(this.label32);
            this.tabPage2.Controls.Add(this.textBoxCItemId);
            this.tabPage2.Controls.Add(this.label31);
            this.tabPage2.Controls.Add(this.textBoxCItemName3);
            this.tabPage2.Controls.Add(this.textBoxCItemName2);
            this.tabPage2.Controls.Add(this.label30);
            this.tabPage2.Controls.Add(this.label29);
            this.tabPage2.Controls.Add(this.radioButton3);
            this.tabPage2.Controls.Add(this.label28);
            this.tabPage2.Controls.Add(this.label27);
            this.tabPage2.Controls.Add(this.buttonCItemDelete);
            this.tabPage2.Controls.Add(this.buttonCItemUpdate);
            this.tabPage2.Controls.Add(this.buttonCItemAdd);
            this.tabPage2.Controls.Add(this.radioButton1);
            this.tabPage2.Controls.Add(this.radioButton2);
            this.tabPage2.Controls.Add(this.label24);
            this.tabPage2.Controls.Add(this.textBoxCItemIndex);
            this.tabPage2.Controls.Add(this.textBoxCItemTitle);
            this.tabPage2.Controls.Add(this.textBoxCItemMemo);
            this.tabPage2.Controls.Add(this.treeViewCollectionDetail);
            this.tabPage2.Controls.Add(this.label25);
            this.tabPage2.Controls.Add(this.textBoxCReleaseDate);
            this.tabPage2.Controls.Add(this.label26);
            this.tabPage2.Controls.Add(this.textBoxCInputDate);
            this.tabPage2.Controls.Add(this.buttonCollectionDelete);
            this.tabPage2.Controls.Add(this.buttonCollectionClear);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.textBoxCName3);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.textBoxCName2);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.textBoxCId);
            this.tabPage2.Controls.Add(this.buttonCollectionUpdate);
            this.tabPage2.Controls.Add(this.buttonCollectionAdd);
            this.tabPage2.Controls.Add(this.textBoxCStatus);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.textBoxCCategory);
            this.tabPage2.Controls.Add(this.label20);
            this.tabPage2.Controls.Add(this.label21);
            this.tabPage2.Controls.Add(this.textBoxCLevel);
            this.tabPage2.Controls.Add(this.label22);
            this.tabPage2.Controls.Add(this.textBoxCMemo);
            this.tabPage2.Controls.Add(this.label23);
            this.tabPage2.Controls.Add(this.textBoxCName);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.checkedListBoxCTags);
            this.tabPage2.Controls.Add(this.treeViewCollection);
            this.tabPage2.Location = new System.Drawing.Point(4, 31);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage2.Size = new System.Drawing.Size(2592, 1515);
            this.tabPage2.TabIndex = 2;
            this.tabPage2.Text = "Collection";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // buttonCItemClear
            // 
            this.buttonCItemClear.Location = new System.Drawing.Point(1278, 703);
            this.buttonCItemClear.Name = "buttonCItemClear";
            this.buttonCItemClear.Size = new System.Drawing.Size(90, 30);
            this.buttonCItemClear.TabIndex = 157;
            this.buttonCItemClear.Text = "Clear";
            this.buttonCItemClear.UseVisualStyleBackColor = true;
            this.buttonCItemClear.Click += new System.EventHandler(this.buttonCItemClear_Click);
            // 
            // buttonTagAdd
            // 
            this.buttonTagAdd.Location = new System.Drawing.Point(2017, 547);
            this.buttonTagAdd.Name = "buttonTagAdd";
            this.buttonTagAdd.Size = new System.Drawing.Size(90, 30);
            this.buttonTagAdd.TabIndex = 156;
            this.buttonTagAdd.Text = "Add";
            this.buttonTagAdd.UseVisualStyleBackColor = true;
            this.buttonTagAdd.Click += new System.EventHandler(this.buttonTagAdd_Click);
            // 
            // textBoxTagAdd
            // 
            this.textBoxTagAdd.Location = new System.Drawing.Point(1869, 546);
            this.textBoxTagAdd.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxTagAdd.Multiline = true;
            this.textBoxTagAdd.Name = "textBoxTagAdd";
            this.textBoxTagAdd.Size = new System.Drawing.Size(142, 31);
            this.textBoxTagAdd.TabIndex = 155;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(1000, 712);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(32, 21);
            this.label32.TabIndex = 154;
            this.label32.Text = "Id";
            // 
            // textBoxCItemId
            // 
            this.textBoxCItemId.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxCItemId.Location = new System.Drawing.Point(1077, 706);
            this.textBoxCItemId.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxCItemId.Name = "textBoxCItemId";
            this.textBoxCItemId.Size = new System.Drawing.Size(147, 31);
            this.textBoxCItemId.TabIndex = 140;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(1001, 811);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(54, 21);
            this.label31.TabIndex = 122;
            this.label31.Text = "Name";
            // 
            // textBoxCItemName3
            // 
            this.textBoxCItemName3.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxCItemName3.Location = new System.Drawing.Point(1483, 860);
            this.textBoxCItemName3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxCItemName3.Multiline = true;
            this.textBoxCItemName3.Name = "textBoxCItemName3";
            this.textBoxCItemName3.Size = new System.Drawing.Size(300, 40);
            this.textBoxCItemName3.TabIndex = 143;
            // 
            // textBoxCItemName2
            // 
            this.textBoxCItemName2.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxCItemName2.Location = new System.Drawing.Point(1077, 863);
            this.textBoxCItemName2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxCItemName2.Multiline = true;
            this.textBoxCItemName2.Name = "textBoxCItemName2";
            this.textBoxCItemName2.Size = new System.Drawing.Size(306, 40);
            this.textBoxCItemName2.TabIndex = 142;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(1402, 866);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(65, 21);
            this.label30.TabIndex = 119;
            this.label30.Text = "Third";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(1001, 863);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(76, 21);
            this.label29.TabIndex = 118;
            this.label29.Text = "Second";
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(1599, 752);
            this.radioButton3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(112, 25);
            this.radioButton3.TabIndex = 132;
            this.radioButton3.Text = "Setting";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(1000, 910);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(54, 21);
            this.label28.TabIndex = 116;
            this.label28.Text = "Memo";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(1001, 757);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(65, 21);
            this.label27.TabIndex = 115;
            this.label27.Text = "Index";
            // 
            // buttonCItemDelete
            // 
            this.buttonCItemDelete.Location = new System.Drawing.Point(1591, 703);
            this.buttonCItemDelete.Name = "buttonCItemDelete";
            this.buttonCItemDelete.Size = new System.Drawing.Size(90, 30);
            this.buttonCItemDelete.TabIndex = 152;
            this.buttonCItemDelete.Text = "Delete";
            this.buttonCItemDelete.UseVisualStyleBackColor = true;
            this.buttonCItemDelete.Click += new System.EventHandler(this.buttonCItemDelete_Click);
            // 
            // buttonCItemUpdate
            // 
            this.buttonCItemUpdate.Location = new System.Drawing.Point(1486, 703);
            this.buttonCItemUpdate.Name = "buttonCItemUpdate";
            this.buttonCItemUpdate.Size = new System.Drawing.Size(90, 30);
            this.buttonCItemUpdate.TabIndex = 151;
            this.buttonCItemUpdate.Text = "Update";
            this.buttonCItemUpdate.UseVisualStyleBackColor = true;
            this.buttonCItemUpdate.Click += new System.EventHandler(this.buttonCItemUpdate_Click);
            // 
            // buttonCItemAdd
            // 
            this.buttonCItemAdd.Location = new System.Drawing.Point(1377, 703);
            this.buttonCItemAdd.Name = "buttonCItemAdd";
            this.buttonCItemAdd.Size = new System.Drawing.Size(90, 30);
            this.buttonCItemAdd.TabIndex = 150;
            this.buttonCItemAdd.Text = "Add";
            this.buttonCItemAdd.UseVisualStyleBackColor = true;
            this.buttonCItemAdd.Click += new System.EventHandler(this.buttonCItemAdd_Click);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(1319, 752);
            this.radioButton1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(134, 25);
            this.radioButton1.TabIndex = 130;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Character";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(1454, 752);
            this.radioButton2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(134, 25);
            this.radioButton2.TabIndex = 131;
            this.radioButton2.Text = "Paragraph";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(1241, 754);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(54, 21);
            this.label24.TabIndex = 109;
            this.label24.Text = "Type";
            // 
            // textBoxCItemIndex
            // 
            this.textBoxCItemIndex.Location = new System.Drawing.Point(1077, 754);
            this.textBoxCItemIndex.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxCItemIndex.Multiline = true;
            this.textBoxCItemIndex.Name = "textBoxCItemIndex";
            this.textBoxCItemIndex.Size = new System.Drawing.Size(147, 31);
            this.textBoxCItemIndex.TabIndex = 140;
            // 
            // textBoxCItemTitle
            // 
            this.textBoxCItemTitle.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxCItemTitle.Location = new System.Drawing.Point(1077, 804);
            this.textBoxCItemTitle.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxCItemTitle.Multiline = true;
            this.textBoxCItemTitle.Name = "textBoxCItemTitle";
            this.textBoxCItemTitle.Size = new System.Drawing.Size(306, 40);
            this.textBoxCItemTitle.TabIndex = 141;
            // 
            // textBoxCItemMemo
            // 
            this.textBoxCItemMemo.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxCItemMemo.Location = new System.Drawing.Point(1000, 954);
            this.textBoxCItemMemo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxCItemMemo.Multiline = true;
            this.textBoxCItemMemo.Name = "textBoxCItemMemo";
            this.textBoxCItemMemo.Size = new System.Drawing.Size(934, 528);
            this.textBoxCItemMemo.TabIndex = 144;
            // 
            // treeViewCollectionDetail
            // 
            this.treeViewCollectionDetail.Location = new System.Drawing.Point(489, 14);
            this.treeViewCollectionDetail.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.treeViewCollectionDetail.Name = "treeViewCollectionDetail";
            treeNode81.Name = "ノード1";
            treeNode81.Text = "Work";
            treeNode82.Name = "ノード2";
            treeNode82.Text = "Life";
            treeNode83.Name = "ノード3";
            treeNode83.Text = "Learn";
            treeNode84.Name = "ノード4";
            treeNode84.Text = "Play";
            treeNode85.Name = "ノード0";
            treeNode85.Text = "Total";
            this.treeViewCollectionDetail.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode85});
            this.treeViewCollectionDetail.Size = new System.Drawing.Size(427, 1468);
            this.treeViewCollectionDetail.TabIndex = 100;
            this.treeViewCollectionDetail.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeViewCollectionDetail_AfterSelect);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(1274, 180);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(131, 21);
            this.label25.TabIndex = 98;
            this.label25.Text = "ReleaseDate";
            // 
            // textBoxCReleaseDate
            // 
            this.textBoxCReleaseDate.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxCReleaseDate.Location = new System.Drawing.Point(1406, 177);
            this.textBoxCReleaseDate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxCReleaseDate.Name = "textBoxCReleaseDate";
            this.textBoxCReleaseDate.Size = new System.Drawing.Size(188, 31);
            this.textBoxCReleaseDate.TabIndex = 105;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(1274, 141);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(109, 21);
            this.label26.TabIndex = 94;
            this.label26.Text = "InputDate";
            // 
            // textBoxCInputDate
            // 
            this.textBoxCInputDate.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxCInputDate.Location = new System.Drawing.Point(1406, 138);
            this.textBoxCInputDate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxCInputDate.Name = "textBoxCInputDate";
            this.textBoxCInputDate.Size = new System.Drawing.Size(188, 31);
            this.textBoxCInputDate.TabIndex = 100;
            // 
            // buttonCollectionDelete
            // 
            this.buttonCollectionDelete.Location = new System.Drawing.Point(1214, 561);
            this.buttonCollectionDelete.Name = "buttonCollectionDelete";
            this.buttonCollectionDelete.Size = new System.Drawing.Size(90, 30);
            this.buttonCollectionDelete.TabIndex = 122;
            this.buttonCollectionDelete.Text = "Delete";
            this.buttonCollectionDelete.UseVisualStyleBackColor = true;
            this.buttonCollectionDelete.Click += new System.EventHandler(this.buttonCollectionDelete_Click);
            // 
            // buttonCollectionClear
            // 
            this.buttonCollectionClear.Location = new System.Drawing.Point(1153, 14);
            this.buttonCollectionClear.Name = "buttonCollectionClear";
            this.buttonCollectionClear.Size = new System.Drawing.Size(90, 30);
            this.buttonCollectionClear.TabIndex = 92;
            this.buttonCollectionClear.Text = "Clear";
            this.buttonCollectionClear.UseVisualStyleBackColor = true;
            this.buttonCollectionClear.Click += new System.EventHandler(this.buttonCollectionClear_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(923, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 21);
            this.label3.TabIndex = 88;
            this.label3.Text = "NameJP";
            // 
            // textBoxCName3
            // 
            this.textBoxCName3.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxCName3.Location = new System.Drawing.Point(1006, 131);
            this.textBoxCName3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxCName3.Name = "textBoxCName3";
            this.textBoxCName3.Size = new System.Drawing.Size(237, 31);
            this.textBoxCName3.TabIndex = 80;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(923, 95);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 21);
            this.label6.TabIndex = 86;
            this.label6.Text = "NameEN";
            // 
            // textBoxCName2
            // 
            this.textBoxCName2.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxCName2.Location = new System.Drawing.Point(1006, 92);
            this.textBoxCName2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxCName2.Name = "textBoxCName2";
            this.textBoxCName2.Size = new System.Drawing.Size(237, 31);
            this.textBoxCName2.TabIndex = 78;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(922, 14);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 21);
            this.label7.TabIndex = 85;
            this.label7.Text = "Id";
            // 
            // textBoxCId
            // 
            this.textBoxCId.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxCId.Location = new System.Drawing.Point(1006, 14);
            this.textBoxCId.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxCId.Name = "textBoxCId";
            this.textBoxCId.Size = new System.Drawing.Size(141, 31);
            this.textBoxCId.TabIndex = 76;
            // 
            // buttonCollectionUpdate
            // 
            this.buttonCollectionUpdate.Location = new System.Drawing.Point(1109, 561);
            this.buttonCollectionUpdate.Name = "buttonCollectionUpdate";
            this.buttonCollectionUpdate.Size = new System.Drawing.Size(90, 30);
            this.buttonCollectionUpdate.TabIndex = 121;
            this.buttonCollectionUpdate.Text = "Update";
            this.buttonCollectionUpdate.UseVisualStyleBackColor = true;
            this.buttonCollectionUpdate.Click += new System.EventHandler(this.buttonCollectionUpdate_Click);
            // 
            // buttonCollectionAdd
            // 
            this.buttonCollectionAdd.Location = new System.Drawing.Point(1000, 561);
            this.buttonCollectionAdd.Name = "buttonCollectionAdd";
            this.buttonCollectionAdd.Size = new System.Drawing.Size(90, 30);
            this.buttonCollectionAdd.TabIndex = 120;
            this.buttonCollectionAdd.Text = "Add";
            this.buttonCollectionAdd.UseVisualStyleBackColor = true;
            this.buttonCollectionAdd.Click += new System.EventHandler(this.buttonCollectionAdd_Click);
            // 
            // textBoxCStatus
            // 
            this.textBoxCStatus.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.textBoxCStatus.Location = new System.Drawing.Point(1406, 102);
            this.textBoxCStatus.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxCStatus.Name = "textBoxCStatus";
            this.textBoxCStatus.Size = new System.Drawing.Size(188, 31);
            this.textBoxCStatus.TabIndex = 95;
            this.textBoxCStatus.Leave += new System.EventHandler(this.textBoxCStatus_Leave);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(1274, 63);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 21);
            this.label8.TabIndex = 84;
            this.label8.Text = "Series";
            // 
            // textBoxCCategory
            // 
            this.textBoxCCategory.Location = new System.Drawing.Point(1406, 63);
            this.textBoxCCategory.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxCCategory.Name = "textBoxCCategory";
            this.textBoxCCategory.Size = new System.Drawing.Size(188, 31);
            this.textBoxCCategory.TabIndex = 90;
            this.textBoxCCategory.Leave += new System.EventHandler(this.textBoxCCategory_Leave);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(1274, 102);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(76, 21);
            this.label20.TabIndex = 81;
            this.label20.Text = "Status";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(923, 173);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(65, 21);
            this.label21.TabIndex = 79;
            this.label21.Text = "Level";
            // 
            // textBoxCLevel
            // 
            this.textBoxCLevel.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxCLevel.Location = new System.Drawing.Point(1006, 170);
            this.textBoxCLevel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxCLevel.Name = "textBoxCLevel";
            this.textBoxCLevel.Size = new System.Drawing.Size(113, 31);
            this.textBoxCLevel.TabIndex = 87;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(922, 223);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(54, 21);
            this.label22.TabIndex = 75;
            this.label22.Text = "Memo";
            // 
            // textBoxCMemo
            // 
            this.textBoxCMemo.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxCMemo.Location = new System.Drawing.Point(1006, 223);
            this.textBoxCMemo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxCMemo.Multiline = true;
            this.textBoxCMemo.Name = "textBoxCMemo";
            this.textBoxCMemo.Size = new System.Drawing.Size(629, 316);
            this.textBoxCMemo.TabIndex = 110;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(923, 56);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(76, 21);
            this.label23.TabIndex = 74;
            this.label23.Text = "NameCN";
            // 
            // textBoxCName
            // 
            this.textBoxCName.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxCName.Location = new System.Drawing.Point(1006, 53);
            this.textBoxCName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxCName.Name = "textBoxCName";
            this.textBoxCName.Size = new System.Drawing.Size(237, 31);
            this.textBoxCName.TabIndex = 77;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1623, 14);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 21);
            this.label9.TabIndex = 30;
            this.label9.Text = "Tags";
            // 
            // checkedListBoxCTags
            // 
            this.checkedListBoxCTags.CheckOnClick = true;
            this.checkedListBoxCTags.FormattingEnabled = true;
            this.checkedListBoxCTags.Location = new System.Drawing.Point(1707, 14);
            this.checkedListBoxCTags.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkedListBoxCTags.MultiColumn = true;
            this.checkedListBoxCTags.Name = "checkedListBoxCTags";
            this.checkedListBoxCTags.Size = new System.Drawing.Size(400, 524);
            this.checkedListBoxCTags.TabIndex = 115;
            // 
            // treeViewCollection
            // 
            this.treeViewCollection.Location = new System.Drawing.Point(7, 14);
            this.treeViewCollection.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.treeViewCollection.Name = "treeViewCollection";
            treeNode86.Name = "ノード1";
            treeNode86.Text = "Work";
            treeNode87.Name = "ノード2";
            treeNode87.Text = "Life";
            treeNode88.Name = "ノード3";
            treeNode88.Text = "Learn";
            treeNode89.Name = "ノード4";
            treeNode89.Text = "Play";
            treeNode90.Name = "ノード0";
            treeNode90.Text = "Total";
            this.treeViewCollection.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode90});
            this.treeViewCollection.Size = new System.Drawing.Size(465, 1468);
            this.treeViewCollection.TabIndex = 4;
            this.treeViewCollection.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeViewCollection_AfterSelect);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label39);
            this.tabPage3.Controls.Add(this.textBoxFReleaseDate);
            this.tabPage3.Controls.Add(this.label40);
            this.tabPage3.Controls.Add(this.textBoxFInputDate);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Controls.Add(this.textBoxFItemId);
            this.tabPage3.Controls.Add(this.label33);
            this.tabPage3.Controls.Add(this.textBoxFItemName3);
            this.tabPage3.Controls.Add(this.textBoxFItemName2);
            this.tabPage3.Controls.Add(this.label34);
            this.tabPage3.Controls.Add(this.label35);
            this.tabPage3.Controls.Add(this.radioButton6);
            this.tabPage3.Controls.Add(this.label36);
            this.tabPage3.Controls.Add(this.label37);
            this.tabPage3.Controls.Add(this.buttonFItemDelete);
            this.tabPage3.Controls.Add(this.buttonFItemUpdate);
            this.tabPage3.Controls.Add(this.buttonFItemAdd);
            this.tabPage3.Controls.Add(this.radioButton4);
            this.tabPage3.Controls.Add(this.radioButton5);
            this.tabPage3.Controls.Add(this.label38);
            this.tabPage3.Controls.Add(this.textBoxFItemIndex);
            this.tabPage3.Controls.Add(this.textBoxFItemName);
            this.tabPage3.Controls.Add(this.textBoxFItemMemo);
            this.tabPage3.Controls.Add(this.treeViewFantasyDetail);
            this.tabPage3.Controls.Add(this.buttonFDelete);
            this.tabPage3.Controls.Add(this.buttonFClear);
            this.tabPage3.Controls.Add(this.label41);
            this.tabPage3.Controls.Add(this.textBoxFName3);
            this.tabPage3.Controls.Add(this.label42);
            this.tabPage3.Controls.Add(this.textBoxFName2);
            this.tabPage3.Controls.Add(this.label43);
            this.tabPage3.Controls.Add(this.textBoxFId);
            this.tabPage3.Controls.Add(this.buttonFUpdate);
            this.tabPage3.Controls.Add(this.buttonFAdd);
            this.tabPage3.Controls.Add(this.textBoxFStatus);
            this.tabPage3.Controls.Add(this.label44);
            this.tabPage3.Controls.Add(this.textBoxFCategory);
            this.tabPage3.Controls.Add(this.label45);
            this.tabPage3.Controls.Add(this.label46);
            this.tabPage3.Controls.Add(this.textBoxFLevel);
            this.tabPage3.Controls.Add(this.label47);
            this.tabPage3.Controls.Add(this.textBoxFMemo);
            this.tabPage3.Controls.Add(this.label48);
            this.tabPage3.Controls.Add(this.textBoxFName);
            this.tabPage3.Controls.Add(this.label49);
            this.tabPage3.Controls.Add(this.checkedListBoxFTags);
            this.tabPage3.Controls.Add(this.treeViewFantasy);
            this.tabPage3.Location = new System.Drawing.Point(4, 31);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage3.Size = new System.Drawing.Size(2592, 1515);
            this.tabPage3.TabIndex = 3;
            this.tabPage3.Text = "Fantasy";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(1273, 177);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(131, 21);
            this.label39.TabIndex = 203;
            this.label39.Text = "ReleaseDate";
            // 
            // textBoxFReleaseDate
            // 
            this.textBoxFReleaseDate.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxFReleaseDate.Location = new System.Drawing.Point(1405, 174);
            this.textBoxFReleaseDate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxFReleaseDate.Name = "textBoxFReleaseDate";
            this.textBoxFReleaseDate.Size = new System.Drawing.Size(188, 31);
            this.textBoxFReleaseDate.TabIndex = 205;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(1273, 138);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(109, 21);
            this.label40.TabIndex = 202;
            this.label40.Text = "InputDate";
            // 
            // textBoxFInputDate
            // 
            this.textBoxFInputDate.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxFInputDate.Location = new System.Drawing.Point(1405, 135);
            this.textBoxFInputDate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxFInputDate.Name = "textBoxFInputDate";
            this.textBoxFInputDate.Size = new System.Drawing.Size(188, 31);
            this.textBoxFInputDate.TabIndex = 204;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(922, 613);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(32, 21);
            this.label10.TabIndex = 201;
            this.label10.Text = "Id";
            // 
            // textBoxFItemId
            // 
            this.textBoxFItemId.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxFItemId.Location = new System.Drawing.Point(999, 607);
            this.textBoxFItemId.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxFItemId.Name = "textBoxFItemId";
            this.textBoxFItemId.Size = new System.Drawing.Size(147, 31);
            this.textBoxFItemId.TabIndex = 193;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(923, 712);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(65, 21);
            this.label33.TabIndex = 188;
            this.label33.Text = "Title";
            // 
            // textBoxFItemName3
            // 
            this.textBoxFItemName3.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxFItemName3.Location = new System.Drawing.Point(1511, 763);
            this.textBoxFItemName3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxFItemName3.Multiline = true;
            this.textBoxFItemName3.Name = "textBoxFItemName3";
            this.textBoxFItemName3.Size = new System.Drawing.Size(300, 40);
            this.textBoxFItemName3.TabIndex = 196;
            // 
            // textBoxFItemName2
            // 
            this.textBoxFItemName2.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxFItemName2.Location = new System.Drawing.Point(1049, 761);
            this.textBoxFItemName2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxFItemName2.Multiline = true;
            this.textBoxFItemName2.Name = "textBoxFItemName2";
            this.textBoxFItemName2.Size = new System.Drawing.Size(300, 40);
            this.textBoxFItemName2.TabIndex = 195;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(1396, 764);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(109, 21);
            this.label34.TabIndex = 184;
            this.label34.Text = "ThirdName";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(923, 764);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(120, 21);
            this.label35.TabIndex = 183;
            this.label35.Text = "SecondName";
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(1516, 608);
            this.radioButton6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(112, 25);
            this.radioButton6.TabIndex = 191;
            this.radioButton6.Text = "Setting";
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(922, 811);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(54, 21);
            this.label36.TabIndex = 182;
            this.label36.Text = "Memo";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(923, 658);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(65, 21);
            this.label37.TabIndex = 181;
            this.label37.Text = "Index";
            // 
            // buttonFItemDelete
            // 
            this.buttonFItemDelete.Location = new System.Drawing.Point(1840, 703);
            this.buttonFItemDelete.Name = "buttonFItemDelete";
            this.buttonFItemDelete.Size = new System.Drawing.Size(90, 30);
            this.buttonFItemDelete.TabIndex = 200;
            this.buttonFItemDelete.Text = "Delete";
            this.buttonFItemDelete.UseVisualStyleBackColor = true;
            this.buttonFItemDelete.Click += new System.EventHandler(this.buttonFItemDelete_Click);
            // 
            // buttonFItemUpdate
            // 
            this.buttonFItemUpdate.Location = new System.Drawing.Point(1735, 703);
            this.buttonFItemUpdate.Name = "buttonFItemUpdate";
            this.buttonFItemUpdate.Size = new System.Drawing.Size(90, 30);
            this.buttonFItemUpdate.TabIndex = 199;
            this.buttonFItemUpdate.Text = "Update";
            this.buttonFItemUpdate.UseVisualStyleBackColor = true;
            this.buttonFItemUpdate.Click += new System.EventHandler(this.buttonFItemUpdate_Click);
            // 
            // buttonFItemAdd
            // 
            this.buttonFItemAdd.Location = new System.Drawing.Point(1626, 703);
            this.buttonFItemAdd.Name = "buttonFItemAdd";
            this.buttonFItemAdd.Size = new System.Drawing.Size(90, 30);
            this.buttonFItemAdd.TabIndex = 198;
            this.buttonFItemAdd.Text = "Add";
            this.buttonFItemAdd.UseVisualStyleBackColor = true;
            this.buttonFItemAdd.Click += new System.EventHandler(this.buttonFItemAdd_Click);
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Checked = true;
            this.radioButton4.Location = new System.Drawing.Point(1236, 608);
            this.radioButton4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(134, 25);
            this.radioButton4.TabIndex = 189;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Character";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(1371, 608);
            this.radioButton5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(134, 25);
            this.radioButton5.TabIndex = 190;
            this.radioButton5.Text = "Paragraph";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(1158, 610);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(54, 21);
            this.label38.TabIndex = 178;
            this.label38.Text = "Type";
            // 
            // textBoxFItemIndex
            // 
            this.textBoxFItemIndex.Location = new System.Drawing.Point(999, 655);
            this.textBoxFItemIndex.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxFItemIndex.Multiline = true;
            this.textBoxFItemIndex.Name = "textBoxFItemIndex";
            this.textBoxFItemIndex.Size = new System.Drawing.Size(147, 31);
            this.textBoxFItemIndex.TabIndex = 192;
            // 
            // textBoxFItemName
            // 
            this.textBoxFItemName.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxFItemName.Location = new System.Drawing.Point(999, 705);
            this.textBoxFItemName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxFItemName.Multiline = true;
            this.textBoxFItemName.Name = "textBoxFItemName";
            this.textBoxFItemName.Size = new System.Drawing.Size(400, 40);
            this.textBoxFItemName.TabIndex = 194;
            // 
            // textBoxFItemMemo
            // 
            this.textBoxFItemMemo.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxFItemMemo.Location = new System.Drawing.Point(999, 811);
            this.textBoxFItemMemo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxFItemMemo.Multiline = true;
            this.textBoxFItemMemo.Name = "textBoxFItemMemo";
            this.textBoxFItemMemo.Size = new System.Drawing.Size(934, 665);
            this.textBoxFItemMemo.TabIndex = 197;
            // 
            // treeViewFantasyDetail
            // 
            this.treeViewFantasyDetail.Location = new System.Drawing.Point(488, 8);
            this.treeViewFantasyDetail.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.treeViewFantasyDetail.Name = "treeViewFantasyDetail";
            treeNode91.Name = "ノード1";
            treeNode91.Text = "Work";
            treeNode92.Name = "ノード2";
            treeNode92.Text = "Life";
            treeNode93.Name = "ノード3";
            treeNode93.Text = "Learn";
            treeNode94.Name = "ノード4";
            treeNode94.Text = "Play";
            treeNode95.Name = "ノード0";
            treeNode95.Text = "Total";
            this.treeViewFantasyDetail.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode95});
            this.treeViewFantasyDetail.Size = new System.Drawing.Size(427, 1468);
            this.treeViewFantasyDetail.TabIndex = 176;
            this.treeViewFantasyDetail.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeViewFantasyDetail_AfterSelect);
            // 
            // buttonFDelete
            // 
            this.buttonFDelete.Location = new System.Drawing.Point(1213, 555);
            this.buttonFDelete.Name = "buttonFDelete";
            this.buttonFDelete.Size = new System.Drawing.Size(90, 30);
            this.buttonFDelete.TabIndex = 187;
            this.buttonFDelete.Text = "Delete";
            this.buttonFDelete.UseVisualStyleBackColor = true;
            this.buttonFDelete.Click += new System.EventHandler(this.buttonFDelete_Click);
            // 
            // buttonFClear
            // 
            this.buttonFClear.Location = new System.Drawing.Point(1152, 8);
            this.buttonFClear.Name = "buttonFClear";
            this.buttonFClear.Size = new System.Drawing.Size(90, 30);
            this.buttonFClear.TabIndex = 171;
            this.buttonFClear.Text = "Clear";
            this.buttonFClear.UseVisualStyleBackColor = true;
            this.buttonFClear.Click += new System.EventHandler(this.buttonFClear_Click);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(922, 128);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(76, 21);
            this.label41.TabIndex = 169;
            this.label41.Text = "NameJP";
            // 
            // textBoxFName3
            // 
            this.textBoxFName3.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxFName3.Location = new System.Drawing.Point(1005, 125);
            this.textBoxFName3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxFName3.Name = "textBoxFName3";
            this.textBoxFName3.Size = new System.Drawing.Size(237, 31);
            this.textBoxFName3.TabIndex = 163;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(922, 89);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(76, 21);
            this.label42.TabIndex = 167;
            this.label42.Text = "NameEN";
            // 
            // textBoxFName2
            // 
            this.textBoxFName2.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxFName2.Location = new System.Drawing.Point(1005, 86);
            this.textBoxFName2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxFName2.Name = "textBoxFName2";
            this.textBoxFName2.Size = new System.Drawing.Size(237, 31);
            this.textBoxFName2.TabIndex = 161;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(921, 8);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(32, 21);
            this.label43.TabIndex = 166;
            this.label43.Text = "Id";
            // 
            // textBoxFId
            // 
            this.textBoxFId.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxFId.Location = new System.Drawing.Point(1005, 8);
            this.textBoxFId.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxFId.Name = "textBoxFId";
            this.textBoxFId.Size = new System.Drawing.Size(141, 31);
            this.textBoxFId.TabIndex = 159;
            // 
            // buttonFUpdate
            // 
            this.buttonFUpdate.Location = new System.Drawing.Point(1108, 555);
            this.buttonFUpdate.Name = "buttonFUpdate";
            this.buttonFUpdate.Size = new System.Drawing.Size(90, 30);
            this.buttonFUpdate.TabIndex = 186;
            this.buttonFUpdate.Text = "Update";
            this.buttonFUpdate.UseVisualStyleBackColor = true;
            this.buttonFUpdate.Click += new System.EventHandler(this.buttonFUpdate_Click);
            // 
            // buttonFAdd
            // 
            this.buttonFAdd.Location = new System.Drawing.Point(999, 555);
            this.buttonFAdd.Name = "buttonFAdd";
            this.buttonFAdd.Size = new System.Drawing.Size(90, 30);
            this.buttonFAdd.TabIndex = 185;
            this.buttonFAdd.Text = "Add";
            this.buttonFAdd.UseVisualStyleBackColor = true;
            this.buttonFAdd.Click += new System.EventHandler(this.buttonFAdd_Click);
            // 
            // textBoxFStatus
            // 
            this.textBoxFStatus.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.textBoxFStatus.Location = new System.Drawing.Point(1405, 96);
            this.textBoxFStatus.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxFStatus.Name = "textBoxFStatus";
            this.textBoxFStatus.Size = new System.Drawing.Size(188, 31);
            this.textBoxFStatus.TabIndex = 173;
            this.textBoxFStatus.Leave += new System.EventHandler(this.textBoxFStatus_Leave);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(1273, 57);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(76, 21);
            this.label44.TabIndex = 165;
            this.label44.Text = "Series";
            // 
            // textBoxFCategory
            // 
            this.textBoxFCategory.Location = new System.Drawing.Point(1405, 57);
            this.textBoxFCategory.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxFCategory.Name = "textBoxFCategory";
            this.textBoxFCategory.Size = new System.Drawing.Size(188, 31);
            this.textBoxFCategory.TabIndex = 170;
            this.textBoxFCategory.Leave += new System.EventHandler(this.textBoxFCategory_Leave);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(1273, 96);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(76, 21);
            this.label45.TabIndex = 164;
            this.label45.Text = "Status";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(922, 167);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(65, 21);
            this.label46.TabIndex = 162;
            this.label46.Text = "Level";
            // 
            // textBoxFLevel
            // 
            this.textBoxFLevel.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxFLevel.Location = new System.Drawing.Point(1005, 164);
            this.textBoxFLevel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxFLevel.Name = "textBoxFLevel";
            this.textBoxFLevel.Size = new System.Drawing.Size(113, 31);
            this.textBoxFLevel.TabIndex = 168;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(921, 217);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(54, 21);
            this.label47.TabIndex = 158;
            this.label47.Text = "Memo";
            // 
            // textBoxFMemo
            // 
            this.textBoxFMemo.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxFMemo.Location = new System.Drawing.Point(1005, 217);
            this.textBoxFMemo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxFMemo.Multiline = true;
            this.textBoxFMemo.Name = "textBoxFMemo";
            this.textBoxFMemo.Size = new System.Drawing.Size(629, 316);
            this.textBoxFMemo.TabIndex = 179;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(922, 50);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(76, 21);
            this.label48.TabIndex = 157;
            this.label48.Text = "NameCN";
            // 
            // textBoxFName
            // 
            this.textBoxFName.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxFName.Location = new System.Drawing.Point(1005, 47);
            this.textBoxFName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxFName.Name = "textBoxFName";
            this.textBoxFName.Size = new System.Drawing.Size(237, 31);
            this.textBoxFName.TabIndex = 160;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(1622, 8);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(54, 21);
            this.label49.TabIndex = 156;
            this.label49.Text = "Tags";
            // 
            // checkedListBoxFTags
            // 
            this.checkedListBoxFTags.CheckOnClick = true;
            this.checkedListBoxFTags.FormattingEnabled = true;
            this.checkedListBoxFTags.Items.AddRange(new object[] {
            "少女",
            "校园",
            "恋爱",
            "搞笑",
            "竞技",
            "游戏",
            "侦探",
            "灵鬼",
            "异能",
            "末世",
            "战争",
            "异界",
            "勇者"});
            this.checkedListBoxFTags.Location = new System.Drawing.Point(1706, 8);
            this.checkedListBoxFTags.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkedListBoxFTags.MultiColumn = true;
            this.checkedListBoxFTags.Name = "checkedListBoxFTags";
            this.checkedListBoxFTags.Size = new System.Drawing.Size(400, 524);
            this.checkedListBoxFTags.TabIndex = 180;
            // 
            // treeViewFantasy
            // 
            this.treeViewFantasy.Location = new System.Drawing.Point(6, 8);
            this.treeViewFantasy.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.treeViewFantasy.Name = "treeViewFantasy";
            treeNode96.Name = "ノード1";
            treeNode96.Text = "Work";
            treeNode97.Name = "ノード2";
            treeNode97.Text = "Life";
            treeNode98.Name = "ノード3";
            treeNode98.Text = "Learn";
            treeNode99.Name = "ノード4";
            treeNode99.Text = "Play";
            treeNode100.Name = "ノード0";
            treeNode100.Text = "Total";
            this.treeViewFantasy.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode100});
            this.treeViewFantasy.Size = new System.Drawing.Size(465, 1468);
            this.treeViewFantasy.TabIndex = 155;
            this.treeViewFantasy.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeViewFantasy_AfterSelect);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.buttonPersonDelete);
            this.tabPage4.Controls.Add(this.buttonPersonClear);
            this.tabPage4.Controls.Add(this.dataGridViewPersonGroup);
            this.tabPage4.Controls.Add(this.label19);
            this.tabPage4.Controls.Add(this.textBoxPersonName3);
            this.tabPage4.Controls.Add(this.label18);
            this.tabPage4.Controls.Add(this.textBoxPersonName2);
            this.tabPage4.Controls.Add(this.label17);
            this.tabPage4.Controls.Add(this.textBoxPersonId);
            this.tabPage4.Controls.Add(this.buttonPersonUpdate);
            this.tabPage4.Controls.Add(this.buttonPersonAdd);
            this.tabPage4.Controls.Add(this.textBoxPersonStatus);
            this.tabPage4.Controls.Add(this.label16);
            this.tabPage4.Controls.Add(this.textBoxPersonGroup);
            this.tabPage4.Controls.Add(this.label5);
            this.tabPage4.Controls.Add(this.label4);
            this.tabPage4.Controls.Add(this.textBoxPersonAddress);
            this.tabPage4.Controls.Add(this.label2);
            this.tabPage4.Controls.Add(this.textBoxPersonMemo);
            this.tabPage4.Controls.Add(this.label1);
            this.tabPage4.Controls.Add(this.textBoxPersonName);
            this.tabPage4.Controls.Add(this.dataGridView3);
            this.tabPage4.Controls.Add(this.treeViewPerson);
            this.tabPage4.Location = new System.Drawing.Point(4, 31);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage4.Size = new System.Drawing.Size(2592, 1515);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "Person";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // buttonPersonDelete
            // 
            this.buttonPersonDelete.Location = new System.Drawing.Point(1208, 614);
            this.buttonPersonDelete.Name = "buttonPersonDelete";
            this.buttonPersonDelete.Size = new System.Drawing.Size(90, 30);
            this.buttonPersonDelete.TabIndex = 73;
            this.buttonPersonDelete.Text = "Delete";
            this.buttonPersonDelete.UseVisualStyleBackColor = true;
            this.buttonPersonDelete.Click += new System.EventHandler(this.buttonPersonDelete_Click);
            // 
            // buttonPersonClear
            // 
            this.buttonPersonClear.Location = new System.Drawing.Point(1141, 28);
            this.buttonPersonClear.Name = "buttonPersonClear";
            this.buttonPersonClear.Size = new System.Drawing.Size(90, 30);
            this.buttonPersonClear.TabIndex = 72;
            this.buttonPersonClear.Text = "Clear";
            this.buttonPersonClear.UseVisualStyleBackColor = true;
            this.buttonPersonClear.Click += new System.EventHandler(this.buttonPersonClear_Click);
            // 
            // dataGridViewPersonGroup
            // 
            this.dataGridViewPersonGroup.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewPersonGroup.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPersonGroup.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn3});
            this.dataGridViewPersonGroup.Location = new System.Drawing.Point(478, 28);
            this.dataGridViewPersonGroup.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridViewPersonGroup.Name = "dataGridViewPersonGroup";
            this.dataGridViewPersonGroup.RowTemplate.Height = 24;
            this.dataGridViewPersonGroup.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewPersonGroup.Size = new System.Drawing.Size(421, 1008);
            this.dataGridViewPersonGroup.TabIndex = 71;
            this.dataGridViewPersonGroup.SelectionChanged += new System.EventHandler(this.dataGridViewPersonGroup_SelectionChanged);
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Total";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(916, 148);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(54, 21);
            this.label19.TabIndex = 32;
            this.label19.Text = "Nick";
            // 
            // textBoxPersonName3
            // 
            this.textBoxPersonName3.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxPersonName3.Location = new System.Drawing.Point(994, 145);
            this.textBoxPersonName3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxPersonName3.Name = "textBoxPersonName3";
            this.textBoxPersonName3.Size = new System.Drawing.Size(237, 31);
            this.textBoxPersonName3.TabIndex = 14;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(916, 109);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(54, 21);
            this.label18.TabIndex = 30;
            this.label18.Text = "Call";
            // 
            // textBoxPersonName2
            // 
            this.textBoxPersonName2.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxPersonName2.Location = new System.Drawing.Point(994, 106);
            this.textBoxPersonName2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxPersonName2.Name = "textBoxPersonName2";
            this.textBoxPersonName2.Size = new System.Drawing.Size(237, 31);
            this.textBoxPersonName2.TabIndex = 13;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(915, 28);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(32, 21);
            this.label17.TabIndex = 28;
            this.label17.Text = "Id";
            // 
            // textBoxPersonId
            // 
            this.textBoxPersonId.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxPersonId.Location = new System.Drawing.Point(994, 28);
            this.textBoxPersonId.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxPersonId.Name = "textBoxPersonId";
            this.textBoxPersonId.Size = new System.Drawing.Size(141, 31);
            this.textBoxPersonId.TabIndex = 11;
            // 
            // buttonPersonUpdate
            // 
            this.buttonPersonUpdate.Location = new System.Drawing.Point(1103, 614);
            this.buttonPersonUpdate.Name = "buttonPersonUpdate";
            this.buttonPersonUpdate.Size = new System.Drawing.Size(90, 30);
            this.buttonPersonUpdate.TabIndex = 52;
            this.buttonPersonUpdate.Text = "Update";
            this.buttonPersonUpdate.UseVisualStyleBackColor = true;
            this.buttonPersonUpdate.Click += new System.EventHandler(this.buttonPersonUpdate_Click);
            // 
            // buttonPersonAdd
            // 
            this.buttonPersonAdd.Location = new System.Drawing.Point(994, 614);
            this.buttonPersonAdd.Name = "buttonPersonAdd";
            this.buttonPersonAdd.Size = new System.Drawing.Size(90, 30);
            this.buttonPersonAdd.TabIndex = 51;
            this.buttonPersonAdd.Text = "Add";
            this.buttonPersonAdd.UseVisualStyleBackColor = true;
            this.buttonPersonAdd.Click += new System.EventHandler(this.buttonPersonAdd_Click);
            // 
            // textBoxPersonStatus
            // 
            this.textBoxPersonStatus.Location = new System.Drawing.Point(1236, 189);
            this.textBoxPersonStatus.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxPersonStatus.Name = "textBoxPersonStatus";
            this.textBoxPersonStatus.Size = new System.Drawing.Size(128, 31);
            this.textBoxPersonStatus.TabIndex = 22;
            this.textBoxPersonStatus.Leave += new System.EventHandler(this.textBoxPersonStatus_Leave);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(916, 194);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(65, 21);
            this.label16.TabIndex = 23;
            this.label16.Text = "Group";
            // 
            // textBoxPersonGroup
            // 
            this.textBoxPersonGroup.Location = new System.Drawing.Point(994, 189);
            this.textBoxPersonGroup.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxPersonGroup.Name = "textBoxPersonGroup";
            this.textBoxPersonGroup.Size = new System.Drawing.Size(141, 31);
            this.textBoxPersonGroup.TabIndex = 21;
            this.textBoxPersonGroup.Leave += new System.EventHandler(this.textBoxPCategory_Leave);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1148, 194);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 21);
            this.label5.TabIndex = 15;
            this.label5.Text = "Status";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(915, 242);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 21);
            this.label4.TabIndex = 13;
            this.label4.Text = "Addr";
            // 
            // textBoxPersonAddress
            // 
            this.textBoxPersonAddress.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxPersonAddress.Location = new System.Drawing.Point(994, 242);
            this.textBoxPersonAddress.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxPersonAddress.Name = "textBoxPersonAddress";
            this.textBoxPersonAddress.Size = new System.Drawing.Size(629, 31);
            this.textBoxPersonAddress.TabIndex = 31;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(916, 291);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 21);
            this.label2.TabIndex = 9;
            this.label2.Text = "Memo";
            // 
            // textBoxPersonMemo
            // 
            this.textBoxPersonMemo.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxPersonMemo.Location = new System.Drawing.Point(994, 291);
            this.textBoxPersonMemo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxPersonMemo.Multiline = true;
            this.textBoxPersonMemo.Name = "textBoxPersonMemo";
            this.textBoxPersonMemo.Size = new System.Drawing.Size(629, 316);
            this.textBoxPersonMemo.TabIndex = 41;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(916, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 21);
            this.label1.TabIndex = 7;
            this.label1.Text = "Name";
            // 
            // textBoxPersonName
            // 
            this.textBoxPersonName.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxPersonName.Location = new System.Drawing.Point(994, 67);
            this.textBoxPersonName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxPersonName.Name = "textBoxPersonName";
            this.textBoxPersonName.Size = new System.Drawing.Size(237, 31);
            this.textBoxPersonName.TabIndex = 12;
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2});
            this.dataGridView3.Location = new System.Drawing.Point(905, 671);
            this.dataGridView3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowTemplate.Height = 24;
            this.dataGridView3.Size = new System.Drawing.Size(1148, 366);
            this.dataGridView3.TabIndex = 61;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Total";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // treeViewPerson
            // 
            this.treeViewPerson.Location = new System.Drawing.Point(7, 28);
            this.treeViewPerson.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.treeViewPerson.Name = "treeViewPerson";
            treeNode101.Name = "ノード1";
            treeNode101.Text = "Work";
            treeNode102.Name = "ノード2";
            treeNode102.Text = "Life";
            treeNode103.Name = "ノード3";
            treeNode103.Text = "Learn";
            treeNode104.Name = "ノード4";
            treeNode104.Text = "Play";
            treeNode105.Name = "ノード0";
            treeNode105.Text = "Total";
            this.treeViewPerson.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode105});
            this.treeViewPerson.Size = new System.Drawing.Size(465, 1008);
            this.treeViewPerson.TabIndex = 3;
            this.treeViewPerson.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeViewPerson_AfterSelect);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.treeViewCategory);
            this.tabPage5.Controls.Add(this.dataGridViewCategoryList);
            this.tabPage5.Controls.Add(this.label15);
            this.tabPage5.Controls.Add(this.textBoxCategoryParent);
            this.tabPage5.Controls.Add(this.buttonAddCategory);
            this.tabPage5.Controls.Add(this.dataGridViewCategory);
            this.tabPage5.Controls.Add(this.buttonUpdateCategory);
            this.tabPage5.Controls.Add(this.dateTimePickerCategory);
            this.tabPage5.Controls.Add(this.label14);
            this.tabPage5.Controls.Add(this.label13);
            this.tabPage5.Controls.Add(this.textBoxCategoryName);
            this.tabPage5.Location = new System.Drawing.Point(4, 31);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(2592, 1515);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Category";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // dataGridViewCategoryList
            // 
            this.dataGridViewCategoryList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewCategoryList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCategoryList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn7});
            this.dataGridViewCategoryList.Location = new System.Drawing.Point(6, 7);
            this.dataGridViewCategoryList.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridViewCategoryList.Name = "dataGridViewCategoryList";
            this.dataGridViewCategoryList.RowTemplate.Height = 24;
            this.dataGridViewCategoryList.Size = new System.Drawing.Size(329, 1031);
            this.dataGridViewCategoryList.TabIndex = 17;
            this.dataGridViewCategoryList.SelectionChanged += new System.EventHandler(this.dataGridViewCategoryList_SelectionChanged);
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "Group";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(523, 124);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(76, 21);
            this.label15.TabIndex = 15;
            this.label15.Text = "Parent";
            // 
            // textBoxCategoryParent
            // 
            this.textBoxCategoryParent.Location = new System.Drawing.Point(602, 118);
            this.textBoxCategoryParent.Name = "textBoxCategoryParent";
            this.textBoxCategoryParent.Size = new System.Drawing.Size(100, 31);
            this.textBoxCategoryParent.TabIndex = 14;
            // 
            // buttonAddCategory
            // 
            this.buttonAddCategory.Location = new System.Drawing.Point(642, 170);
            this.buttonAddCategory.Name = "buttonAddCategory";
            this.buttonAddCategory.Size = new System.Drawing.Size(90, 30);
            this.buttonAddCategory.TabIndex = 13;
            this.buttonAddCategory.Text = "Add";
            this.buttonAddCategory.UseVisualStyleBackColor = true;
            this.buttonAddCategory.Click += new System.EventHandler(this.buttonAddCategory_Click);
            // 
            // dataGridViewCategory
            // 
            this.dataGridViewCategory.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewCategory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCategory.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CategoryName,
            this.ParentCategory});
            this.dataGridViewCategory.Location = new System.Drawing.Point(526, 226);
            this.dataGridViewCategory.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridViewCategory.Name = "dataGridViewCategory";
            this.dataGridViewCategory.RowTemplate.Height = 24;
            this.dataGridViewCategory.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewCategory.Size = new System.Drawing.Size(420, 782);
            this.dataGridViewCategory.TabIndex = 12;
            // 
            // CategoryName
            // 
            this.CategoryName.HeaderText = "Name";
            this.CategoryName.Name = "CategoryName";
            // 
            // ParentCategory
            // 
            this.ParentCategory.HeaderText = "Parent";
            this.ParentCategory.Name = "ParentCategory";
            // 
            // buttonUpdateCategory
            // 
            this.buttonUpdateCategory.Location = new System.Drawing.Point(526, 170);
            this.buttonUpdateCategory.Name = "buttonUpdateCategory";
            this.buttonUpdateCategory.Size = new System.Drawing.Size(90, 30);
            this.buttonUpdateCategory.TabIndex = 11;
            this.buttonUpdateCategory.Text = "Update";
            this.buttonUpdateCategory.UseVisualStyleBackColor = true;
            this.buttonUpdateCategory.Click += new System.EventHandler(this.buttonUpdateCategory_Click);
            // 
            // dateTimePickerCategory
            // 
            this.dateTimePickerCategory.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerCategory.Location = new System.Drawing.Point(602, 66);
            this.dateTimePickerCategory.Name = "dateTimePickerCategory";
            this.dateTimePickerCategory.Size = new System.Drawing.Size(155, 31);
            this.dateTimePickerCategory.TabIndex = 4;
            this.dateTimePickerCategory.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(523, 69);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(54, 21);
            this.label14.TabIndex = 3;
            this.label14.Text = "Date";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(523, 17);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(54, 21);
            this.label13.TabIndex = 1;
            this.label13.Text = "Name";
            // 
            // textBoxCategoryName
            // 
            this.textBoxCategoryName.Location = new System.Drawing.Point(602, 14);
            this.textBoxCategoryName.Name = "textBoxCategoryName";
            this.textBoxCategoryName.Size = new System.Drawing.Size(100, 31);
            this.textBoxCategoryName.TabIndex = 0;
            // 
            // buttonEventSave
            // 
            this.buttonEventSave.Location = new System.Drawing.Point(1126, 23);
            this.buttonEventSave.Name = "buttonEventSave";
            this.buttonEventSave.Size = new System.Drawing.Size(120, 40);
            this.buttonEventSave.TabIndex = 10;
            this.buttonEventSave.Text = "Save";
            this.buttonEventSave.UseVisualStyleBackColor = true;
            this.buttonEventSave.Click += new System.EventHandler(this.buttonEventSave_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(18, 14);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.ShowUpDown = true;
            this.dateTimePicker1.Size = new System.Drawing.Size(194, 37);
            this.dateTimePicker1.TabIndex = 2;
            this.dateTimePicker1.Value = new System.DateTime(2001, 1, 1, 0, 0, 0, 0);
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.label11.Location = new System.Drawing.Point(240, 22);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(101, 30);
            this.label11.TabIndex = 3;
            this.label11.Text = "Total : ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.label12.Location = new System.Drawing.Point(344, 23);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(49, 30);
            this.label12.TabIndex = 4;
            this.label12.Text = "0.0";
            // 
            // buttonEventView
            // 
            this.buttonEventView.Location = new System.Drawing.Point(547, 23);
            this.buttonEventView.Name = "buttonEventView";
            this.buttonEventView.Size = new System.Drawing.Size(120, 40);
            this.buttonEventView.TabIndex = 18;
            this.buttonEventView.Text = "EventView";
            this.buttonEventView.UseVisualStyleBackColor = true;
            this.buttonEventView.Click += new System.EventHandler(this.buttonEventView_Click);
            // 
            // buttonUpdate
            // 
            this.buttonUpdate.Location = new System.Drawing.Point(1300, 23);
            this.buttonUpdate.Name = "buttonUpdate";
            this.buttonUpdate.Size = new System.Drawing.Size(120, 40);
            this.buttonUpdate.TabIndex = 19;
            this.buttonUpdate.Text = "Update";
            this.buttonUpdate.UseVisualStyleBackColor = true;
            this.buttonUpdate.Click += new System.EventHandler(this.buttonUpdate_Click);
            // 
            // buttonBackup
            // 
            this.buttonBackup.Location = new System.Drawing.Point(1812, 23);
            this.buttonBackup.Name = "buttonBackup";
            this.buttonBackup.Size = new System.Drawing.Size(120, 40);
            this.buttonBackup.TabIndex = 20;
            this.buttonBackup.Text = "Backup";
            this.buttonBackup.UseVisualStyleBackColor = true;
            this.buttonBackup.Click += new System.EventHandler(this.buttonBackup_Click);
            // 
            // buttonEventSearch
            // 
            this.buttonEventSearch.Location = new System.Drawing.Point(927, 8);
            this.buttonEventSearch.Name = "buttonEventSearch";
            this.buttonEventSearch.Size = new System.Drawing.Size(120, 40);
            this.buttonEventSearch.TabIndex = 11;
            this.buttonEventSearch.Text = "Search";
            this.buttonEventSearch.UseVisualStyleBackColor = true;
            this.buttonEventSearch.Click += new System.EventHandler(this.buttonEventSearch_Click);
            // 
            // textBoxEventSearch
            // 
            this.textBoxEventSearch.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.textBoxEventSearch.Location = new System.Drawing.Point(479, 8);
            this.textBoxEventSearch.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxEventSearch.Multiline = true;
            this.textBoxEventSearch.Name = "textBoxEventSearch";
            this.textBoxEventSearch.Size = new System.Drawing.Size(442, 40);
            this.textBoxEventSearch.TabIndex = 143;
            // 
            // FormDiary
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2778, 1644);
            this.Controls.Add(this.buttonBackup);
            this.Controls.Add(this.buttonEventSave);
            this.Controls.Add(this.buttonUpdate);
            this.Controls.Add(this.buttonEventView);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.tabControl1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "FormDiary";
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEvent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPersonGroup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCategoryList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCategory)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridViewEvent;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TreeView treeViewCollection;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn9;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.CheckedListBox checkedListBoxCTags;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button buttonAddSelectRows;
        private System.Windows.Forms.Button buttonEventSave;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TextBox textBoxCategoryName;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DateTimePicker dateTimePickerCategory;
        private System.Windows.Forms.Button buttonUpdateCategory;
        private System.Windows.Forms.DataGridView dataGridViewCategory;
        private System.Windows.Forms.DataGridViewTextBoxColumn CategoryName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ParentCategory;
        private System.Windows.Forms.Button buttonAddCategory;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBoxCategoryParent;
        private System.Windows.Forms.DataGridView dataGridViewCategoryList;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.Button buttonEventView;
        private System.Windows.Forms.Button buttonUpdate;
        private System.Windows.Forms.TreeView treeViewCategory;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxPersonAddress;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxPersonMemo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxPersonName;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.TreeView treeViewPerson;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBoxPersonGroup;
        private System.Windows.Forms.TextBox textBoxPersonStatus;
        private System.Windows.Forms.Button buttonPersonAdd;
        private System.Windows.Forms.Button buttonPersonUpdate;
        private System.Windows.Forms.Button buttonBackup;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBoxPersonId;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBoxPersonName2;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBoxPersonName3;
        private System.Windows.Forms.DataGridView dataGridViewPersonGroup;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.Button buttonPersonClear;
        private System.Windows.Forms.Button buttonPersonDelete;
        private System.Windows.Forms.Button buttonCollectionDelete;
        private System.Windows.Forms.Button buttonCollectionClear;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxCName3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxCName2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxCId;
        private System.Windows.Forms.Button buttonCollectionUpdate;
        private System.Windows.Forms.Button buttonCollectionAdd;
        private System.Windows.Forms.TextBox textBoxCStatus;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxCCategory;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBoxCLevel;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBoxCMemo;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox textBoxCName;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBoxCReleaseDate;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox textBoxCInputDate;
        private System.Windows.Forms.TreeView treeViewCollectionDetail;
        private System.Windows.Forms.Button buttonCItemDelete;
        private System.Windows.Forms.Button buttonCItemUpdate;
        private System.Windows.Forms.Button buttonCItemAdd;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBoxCItemIndex;
        private System.Windows.Forms.TextBox textBoxCItemTitle;
        private System.Windows.Forms.TextBox textBoxCItemMemo;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox textBoxCItemName3;
        private System.Windows.Forms.TextBox textBoxCItemName2;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox textBoxCItemId;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxFItemId;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox textBoxFItemName3;
        private System.Windows.Forms.TextBox textBoxFItemName2;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Button buttonFItemDelete;
        private System.Windows.Forms.Button buttonFItemUpdate;
        private System.Windows.Forms.Button buttonFItemAdd;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox textBoxFItemIndex;
        private System.Windows.Forms.TextBox textBoxFItemName;
        private System.Windows.Forms.TextBox textBoxFItemMemo;
        private System.Windows.Forms.TreeView treeViewFantasyDetail;
        private System.Windows.Forms.Button buttonFDelete;
        private System.Windows.Forms.Button buttonFClear;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBoxFName3;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox textBoxFName2;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox textBoxFId;
        private System.Windows.Forms.Button buttonFUpdate;
        private System.Windows.Forms.Button buttonFAdd;
        private System.Windows.Forms.TextBox textBoxFStatus;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox textBoxFCategory;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox textBoxFLevel;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox textBoxFMemo;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox textBoxFName;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.CheckedListBox checkedListBoxFTags;
        private System.Windows.Forms.TreeView treeViewFantasy;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox textBoxFReleaseDate;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox textBoxFInputDate;
        private System.Windows.Forms.Button buttonTagAdd;
        private System.Windows.Forms.TextBox textBoxTagAdd;
        private System.Windows.Forms.Button buttonCItemClear;
        private System.Windows.Forms.Button buttonEventSearch;
        private System.Windows.Forms.TextBox textBoxEventSearch;
    }
}

