﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace WlyParser
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length == 3)
            {
                if (args[0] == "-pf")
                {
                    WlyParser.ParseFolder(args[1], args[2]);
                }
                else if (args[0] == "-df")
                {
                    WlyParser.DeParseFolder(args[1], args[2]);
                }
                else if (args[0] == "-p")
                {

                }
                else if (args[0] == "-d")
                {

                }
                else
                {
                    Console.WriteLine("Parameter must be [-p path1 path2] or [-d path1 path2 ] or [-f path1 path2 ].");
                }
            }
            else
            {
                Console.WriteLine("Program must have 3 parameters.");
            }
        }
    }
}
