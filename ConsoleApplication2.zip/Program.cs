﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {

            string conn_str = "Server=gnm-devrtft01;Port=5432;User ID=postgres;Database=note;Password=TSSummit00#;Enlist=true";

            using (NpgsqlConnection conn = new NpgsqlConnection(conn_str))
            {
                //PostgreSQLへ接続
                conn.Open();

                string cmd_str = "DELETE FROM person where id=1 ";
                NpgsqlCommand cmd = new NpgsqlCommand(cmd_str, conn);
                cmd.ExecuteNonQuery();
                Console.WriteLine("Connection success!");

                conn.Close();
            }
        }
    }
}
