﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WlyParser
{
    class WlyParser
    {

        public static byte[] ReadFile(string filePath)
        {
            using (var fs = new FileStream(filePath, FileMode.Open, FileAccess.Read))
            {
                var buffer = new byte[fs.Length];
                fs.Read(buffer, 0, buffer.Length);
                return buffer;
            }
        }

        public static void WriteFile(byte[] buffer, string filePath)
        {
            using (var fs = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.Write))
            {
                fs.Write(buffer, 0, buffer.Length);
            }
        }


        public static byte[] Parse(byte[] buffer)
        {
            int newLen = buffer.Length + 2 + 7 + 10;
            var newBuff = new byte[newLen];

            newBuff[0] = Byte.Parse("80");
            newBuff[1] = Byte.Parse("00");
            newBuff[2] = Byte.Parse("00");
            newBuff[3] = Byte.Parse("50");
            newBuff[4] = Byte.Parse("00");

            for (int i = 5; i < 19; i++)
            {
                newBuff[i] = buffer[i - 2];
            }

            for (int i = 19; i < 26; i++)
            {
                newBuff[i] = Byte.Parse("66");
            }

            for (int i = 26; i < buffer.Length + 9; i++)
            {
                newBuff[i] = buffer[i - 9];
            }

            for (int i = buffer.Length + 9; i < newLen; i++)
            {
                newBuff[i] = Byte.Parse("66");
            }


            return newBuff;
        }


        public static byte[] DeParse(byte[] buffer)
        {
            int newLen = buffer.Length - 10 + 2 - 7;
            var newBuff = new byte[newLen];

            newBuff[0] = Byte.Parse("80");
            newBuff[1] = Byte.Parse("00");
            newBuff[2] = Byte.Parse("00");
            newBuff[3] = Byte.Parse("50");
            newBuff[4] = Byte.Parse("00");

            int bufLen1 = 17 + 5 - 3;
            for (int i = 5; i < bufLen1; i++)
            {
                newBuff[i] = buffer[i - 2];
            }

            int bufLen2 = newLen;
            for (int i = 26; i < newLen; i++)
            {
                newBuff[i] = buffer[i - 9];
            }

            return newBuff;
        }

        public static void ParseFile(string inPath, string outPath)
        {
            byte[] buf = ReadFile(inPath);
            byte[] newBuf = Parse(buf);
            WriteFile(newBuf, outPath);
        }

        public static void DeParseFile(string inPath, string outPath)
        {
            byte[] buf = ReadFile(inPath);
            byte[] newBuf = DeParse(buf);
            WriteFile(newBuf, outPath);
        }

        public static void ParseFolder(string inPath, string outPath)
        {
            System.IO.DirectoryInfo di = new System.IO.DirectoryInfo(inPath);
            System.IO.FileInfo[] files =
                di.GetFiles("*.*", System.IO.SearchOption.AllDirectories);

            if (files.Length == 0)
            {
                Console.WriteLine("No file is found.");
            }

            //ListBox1に結果を表示する
            foreach (System.IO.FileInfo f in files)
            {
                byte[] buf = ReadFile(f.FullName);
                byte[] newBuf = Parse(buf);
                WriteFile(newBuf, outPath + "\\" + f.Name);
                Console.WriteLine("Parse completed : " + f.FullName );
            }


        }



    }
}
